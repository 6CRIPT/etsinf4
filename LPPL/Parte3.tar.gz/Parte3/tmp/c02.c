// Ejemplo de uso de asignaciones como expresiones.
// Debe devolver: 28, 28, 14, 14, 14
//----------------------------------------------------------
int main ()
{ int A[3]; int a; int b; int c;

  b=7;
  A[a=2]=28;  print(c=A[2]); print (c);
  print(a=b=a*b); print(a); print(b);

  return 0;
} 
