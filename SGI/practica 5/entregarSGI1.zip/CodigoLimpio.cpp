/***************************************************
*	Pulpo.cpp
*
*	Animacion coherente con el tiempo transcurrido
*
*	@author	C�sar Mart�nez Chico
*	@date Oct,2023
*
*   @nota: he usado como plantilla la practica 5 de animaciones
*	@nota2: Mi proyecto consiste en 3 modos de funcionamiento (animaciones)
*			En el primero modo, como pide la practica los brazos giran sobre el eje y ademas suben y bajan. Duracion => 8 segundos
*			En el segundo modo, dejan de subir y bajar y siguen girando con velocidad constante. Duracion => 3 segundos
*			En el tercer modo, cambian de velocidad y giran mas rapido. Duracion => hasta parar la aplicacion.
*	@nota3: Puede desactivar el giro de la camara para ver solo el giro de la figura descomentando la linea del display del glutlookat que usa el array ojo y descomentando el que no lo usa
***************************************************/
#define PROYECTO "Animacion"

#include <iostream>	
#include <sstream>
#include <codebase.h>
#define _USE_MATH_DEFINES
#include <math.h>

using namespace std;
using namespace cb;

// Globales
static float alfa = 0;
static float beta = 0;
static float delta = 0;
static string direccion = "arriba";
static string cayendo = "adelante";
static float TASA_REFRESCO = 60; 
static GLuint estrella;

//camara
static const float radioCamara = 5.0; // Radio de giro de la camara
static float anguloCamara = 0.0; 
static float ojo[] = { 0,0,radioCamara };
static const float velocidadCamara = 24.0 * 3.1415926 / 180;

// Funcion de inicializacion propia
void init()
{
	// Salida por consola
	cout << glGetString(GL_VERSION) << endl;
	// Configuracion del motor de render
	glEnable(GL_DEPTH_TEST);
}

// Funcion que cuenta los fotogramas por segundo calculados
// y los muestra en el titulo de la ventana
void FPS()
{
	static int antes = glutGet(GLUT_ELAPSED_TIME);
	int ahora = glutGet(GLUT_ELAPSED_TIME);
	int tiempo_transcurrido = ahora - antes;
	static int fotogramas = 0;

	fotogramas++;

	if (tiempo_transcurrido >= 1000) {
		// Cambiar el titulo de la ventana
		stringstream titulo;
		titulo << "FPS=" << fotogramas;
		glutSetWindowTitle(titulo.str().c_str());
		fotogramas = 0;
		antes = ahora;
	}

}

//FUNCION PARA GENERAR LA ESTRELLA (GEOMETRIA DE LA PRACTICA 4) COMO PIDE LA PRACTICA
void generarEstrella()
{
	estrella = glGenLists(1); 
	glNewList(estrella, GL_COMPILE);
	
	glBegin(GL_TRIANGLE_STRIP);
	for (int i = 0; i < 4; i++) {
		double angle = (1.0 + (i * 4) % 12) * M_PI / 6;
		glVertex3f(1.0 * cos(angle), 1.0 * sin(angle), 0.0);
		glVertex3f(0.7 * cos(angle), 0.7 * sin(angle), 0.0);
	}
	glEnd();

	glBegin(GL_TRIANGLE_STRIP);
	for (int i = 0; i < 4; i++) {
		double angle = (3.0 + (i * 4) % 12) * M_PI / 6;
		glVertex3f(1.0 * cos(angle), 1.0 * sin(angle), 0.0);
		glVertex3f(0.7 * cos(angle), 0.7 * sin(angle), 0.0);
	}
	glEnd();
	glEndList();
	glEnable(GL_DEPTH_TEST);
	glPushMatrix();
	for (float i = 1; i <= 6; i = i + 1) {
		float mod = i / 10;
		glColor3f(1 - mod, 1 - mod, 0 + mod);
		glRotatef(30, 0, 1, 0);
		glCallList(estrella);
	}
	glPopMatrix();
}

//FUNCION PARA GENERAR UNOS ARITOS EN LAS "RODILLAS DEL PULPO" SIMPLE DECORACION
void generarAros()
{
	for (int i = 0; i < 2; i++)
	{
		double x = (i * 0.05) + 0.2;
		glTranslatef(0.0, 0.0, x);
		glColor3f(0.6, 0.7, 0.9);
		glutSolidSphere(0.1, 30, 30);
	}
}

//FUNCION PARA GENERAR DEDOS Y VAGONES QUE SE UNIRAN A LA ARTICULACION DEL PULPO
void generarDedosYVagones() 
{
	glRotatef(60, 1,0,0);
	glColor3f(0.6, 0.7, 0.9);
	glutSolidCylinder(0.03, 0.5, 20, 20);
	glRotatef(-60, 1, 0, 0);
	glTranslatef(0,-0.5,0.3);
	glColor3f(0.5, 0.0, 0.5);
	glutSolidCube(0.3);
}

//FUNCION PARA GENERAR UNA PATA. USA LAS DOS ANTERIORES.
void drawLeg()
{
	//femur 
	glColor3f(0.5, 0.0, 0.5);
	glRotatef(-120, 1, 0, 0);
	glTranslatef(0,-1,-1); 
	glutSolidCylinder(0.1, 3, 20, 20);

	//rodilla
	glRotatef(120, 1, 0, 0);
	glTranslatef(0, -1.9, -1.5);
	glutSolidCylinder(0.1, 0.6, 20, 20);

	//bola para dar mas naturalidad a la articulacion
	glutSolidSphere(0.1, 30, 30);

	//aros
	generarAros();

	//bolas articulables
	//glRotatef(120, 1, 0, 0);
	glRotatef(alfa, 0, 0, 1);
	glTranslatef(0, 0, 0.2);
	glutSolidSphere(0.2, 30, 30);

	//dedos y vagones
	static float angle = 0.0; //uso este angulo para generar 3 dedos&vagones por cada pata.
	for (int i = 0; i < 3; i++) {
		glPushMatrix();
		glRotatef(angle + i * 120, 0, 0, 1);
		generarDedosYVagones();
		glPopMatrix();
	}
	

}

//FUNCION QUE DIBUJA LA BOCA
void drawMouth()
{
	glColor3f(1.0, 1.0, 1.0); // Color blanco para los dientes.

	glBegin(GL_POLYGON);
	for (int i = 0; i <= 180; i++)
	{
		float angle = i * 3.14159 / 180;
		float x = 0.3 * cos(angle);
		float y = -0.15 * sin(angle);
		glVertex3f(x, y, 0.5);
	}
	glEnd();

	// Labios
	glLineWidth(2.5); // Grosor
	glColor3f(1.0, 0.5, 0.5); // Color rosa
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i <= 180; i++)
	{
		float angle = i * 3.14159 / 180;
		float x = 0.3 * cos(angle);
		float y = -0.15 * sin(angle);
		glVertex3f(x, y, 0.5);
	}
	glEnd();
}

//funcion para dibujar un brazo.
void drawArm() {
	//brazo
	glColor3f(0.5, 0.0, 0.5);
	glRotatef(90, 1, 0, 0); // Gira el cilindro 90 grados alrededor del eje X
	glTranslatef(0.0, 0.3, 0);
	glutSolidCylinder(0.1, 0.7, 20, 20);

	//codo
	glTranslatef(0.0,0.0,0.7);
	glutSolidSphere(0.1, 30,30);
	glRotatef(90,1,0,0);
	glutSolidCylinder(0.1,0.2,30,30);

	//mano
	glTranslatef(0.0, 0.0, 0.2);
	glutSolidCone(0.1, 0.3, 30, 300);
}

//Funcion que va a dibujar la geometria de la practica 4 usando la estrella definida m�s arriba.
void dibujarEstrellaDeDavid() {
	glPushMatrix();
	glScalef(0.5, 0.5, 0.5);
	glRotatef(alfa, 0, 1, 0);
	for (float i = 1; i <= 6; i = i + 1) {
		float mod = i / 10;
		glColor3f(1 - mod, 1 - mod, 0 + mod);
		glRotatef(30, 0, 1, 0);
		glCallList(estrella);
	}
	glColor3f(0.68, 0.85, 0.90);
	glutWireSphere(1, 20, 20);
	glPopMatrix();
}

// Funcion de atencion al evento de dibujo
void display()
{
	glClearColor(0.9, 0.95, 1.0, 1.0); // Color de fondo azul muy claro
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	gluLookAt(ojo[0] + 12, ojo[1] + 2, ojo[2] + 3, 0, 0, 0, 0, 1, 0);
	//gluLookAt(12, 3, 4, 0, 0, 0, 0, 1, 0); //descomentar para ver el giro normal de la figura, sin giro de camara

	ejes();

	//estrella
	glPushMatrix();
	glTranslatef(0,2,0);
	dibujarEstrellaDeDavid();
	glPopMatrix();

	//CABEZA
	glPushMatrix(); 
	glTranslatef(0, 0.9, 0);
	glRotatef(alfa, 0, 1, 0);
	glColor3f(0.6, 0.7, 0.9);
	glutSolidSphere(0.5, 30, 30);
	glPopMatrix(); //pop del estado del circulo

	// PRIMER OJO
	glPushMatrix();
	glRotatef(alfa, 0, 1, 0);
	glTranslatef(0.2, 1.0, 0.3); 
	glScalef(0.2, 0.2, 0.2); 
	glColor3f(1.0, 0.5, 0.0); // Color blanco 
	glutSolidSphere(1.0, 30, 30);
	glPopMatrix(); //pop del ojo derecho

	// SEGUNDO OJO
	glPushMatrix();
	glRotatef(alfa, 0, 1, 0);
	glTranslatef(-0.2, 1.0, 0.3); 
	glScalef(0.2, 0.2, 0.2); 
	glColor3f(1.0, 0.5, 0.0); 
	glutSolidSphere(1.0, 30, 30);
	glPopMatrix(); //pop del otro ojo

	//BOCA
	glPushMatrix();
	glRotatef(alfa, 0, 1, 0);
	glTranslatef(0, 0.85, 0); 
	drawMouth(); //funcion definida arriba para dibujar la boca
	glPopMatrix();

	//cilindro CUERPO
	glTranslatef(0, 0.4, 0);
	glRotatef(alfa / 2, 0, 1, 0);
	glColor3f(0.6, 0.7, 0.9);
	glRotatef(90, 1, 0, 0);
	glutSolidCylinder(0.5, 2, 20, 20);

	// BRAZOS
	static float angle = 0.0;
	for (int i = 0; i < 4; i++) {
		glPushMatrix();
		glRotatef((angle + i * 90) + 45, 0, 0, 1);
		drawArm(); //funcion definida arriba para dibujar los brazos.
		glPopMatrix();
	}

	//PATAS
	glPushMatrix();
	glRotatef(alfa, 0, 0, 1);
	static float angle2 = 0.0;
	for (int i = 0; i < 4; ++i)
	{
		glPushMatrix();
		glRotatef(delta, 0, 0, 1);
		glTranslatef(0, 0, beta); 
		glRotatef((angle2 + i * 90) + 45, 0, 0, 1); // Rota cada pata 90 grados m�s que la anterior
		drawLeg(); // Llama al m�todo drawLeg() para dibujar la pata
		glPopMatrix();
	}
	glPopMatrix();
	
	glutSwapBuffers();
	FPS();
}

// Funcion de atencion al redimensionamiento
void reshape(GLint w, GLint h)
{
	float ra = (float)w / h;
	glViewport(0, 0, w, h);

	// Elegir la camara
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	/*
	if (ra > 1)
		glOrtho(-2 * ra, 2 * ra, -2, 2, -1,1 );
	else
		glOrtho(-2, 2, -2 / ra, 2 / ra, -1, 1);
	*/

	gluPerspective(30, ra, 0.1, 100);
}


static void onIdle()
// Funcion de atencion al evento idle
{
	static int antes = 0;
	int ahora, tiempo_transcurrido;
	ahora = glutGet(GLUT_ELAPSED_TIME); 
	tiempo_transcurrido = ahora - antes; 
	anguloCamara += velocidadCamara * tiempo_transcurrido / 1000.0;
	ojo[0] = radioCamara * sin(anguloCamara);
	ojo[2] = radioCamara * cos(anguloCamara);
	antes = ahora;
	glutPostRedisplay();
}
void update()
{
	// Actualizacion de variables sin tener en cuenta el tiempo
	// alfa += 0.1;

	// Actualizacion dependiendo del tiempo transcurrido
	static const float vueltasxsegundo = 0.5;
	static int hora_anterior = glutGet(GLUT_ELAPSED_TIME);
	int hora_actual = glutGet(GLUT_ELAPSED_TIME);
	float tiempo_transcurrido = (hora_actual - hora_anterior) / 1000.0f;

	alfa += vueltasxsegundo * 360 /*grados por vuelta*/ * tiempo_transcurrido;
	//beta += vueltasxsegundo * 30 * tiempo_transcurrido;

	hora_anterior = hora_actual;

	glutPostRedisplay();
}

// Atender al timer
void onTimer(int tiempo)
{
	glutTimerFunc(tiempo, onTimer, tiempo);
	static int hora_anterior = 0;
	int hora_actual = glutGet(GLUT_ELAPSED_TIME);
	float tiempo_transcurrido = (hora_actual - hora_anterior) / 1000.0f;
	if (tiempo_transcurrido < 8) { //MODO 1

		if (direccion == "arriba") {
			beta -= 0.01;
		}
		if (direccion == "abajo") {
			beta += 0.01;
		}
		if (beta >= 0.6) {
			direccion = "arriba";
		}
		if (beta <= 0) {
			direccion = "abajo";
		}
	}
	if (tiempo_transcurrido >= 8 and direccion == "abajo" and tiempo_transcurrido < 11) { //MODO 2
		beta = 0;
	}
	
	if (tiempo_transcurrido >= 11) { //MODO 3
		delta = alfa + 30;
	}
	update();
}

int main(int argc, char** argv)
{
	// Inicializaciones
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1100, 1100);
	glutInitWindowPosition(50, 50);

	// Crear ventana
	glutCreateWindow(PROYECTO);
	generarEstrella();
	// Registrar callbacks
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutIdleFunc(onIdle); //idle ANTES
	//glutIdleFunc(update);
	glutTimerFunc(int(1000 / TASA_REFRESCO), onTimer, int(1000 / TASA_REFRESCO));

	// Inicio propio y del bucle de eventos
	init();
	glutMainLoop();
}